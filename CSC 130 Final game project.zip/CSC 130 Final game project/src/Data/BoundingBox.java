package Data;

public class BoundingBox {
	public Coordinates TopLeft;
	public Coordinates BottomRight;
	
	
	public BoundingBox(Coordinates tl, Coordinates br) {
		TopLeft = tl;
		BottomRight = br;
		
	}


}
